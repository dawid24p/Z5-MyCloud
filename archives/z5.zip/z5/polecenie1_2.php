<?php declare(strict_types=1);
require __DIR__.'/index2.php';
